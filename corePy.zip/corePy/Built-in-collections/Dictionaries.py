
# names_and_ages = [('Alice', 32), ('Bob', 48), ('Charlie', 28),('Daniel', 33)]
# d = dict(names_and_ages)
# print(d)

d = dict(goldenrod=0xDAA520, indigo=0x4B00082, seashell=0xFFF5EE)
e = d.copy()
print(e)

f = dict(e)
print(f)

g = dict(wheat=0xF5DB3, Khaki=0xF0E68C, crimson=0xDC143C)
f.update(g)
print(f)

stocks = {'GOOG': 891, 'AAPL': 416, 'IBM':194}
stocks.update({'GOOG': 894, 'YHOO': 25})
print(stocks)

colors = dict(aquamarine='#7FFFD4', burlywood='#DE8887',
           chartreuse='7FFF00',cornflower='#6495ED',
           firebrick='#B22222',honeydew='#F0FFF0',
           maroon='#B03060',sienna='#A0522D')
for key in colors:
  print(f"{key} =>{colors[key]}")


for value in colors.values():
  print(value)       

for key in colors.keys():
  print(key) 

for key, value in colors.items():
  print(f"{key}=>{value}")
  

