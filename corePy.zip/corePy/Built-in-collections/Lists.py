r = [1, -4, 10 -16, 15]
print(r[-1])
print(r[-2])
print(r[len(r) - 1])
print(r[0])
print(r[-0])

s = [3, 186, 4431, 74400, 1048443]
print(s[1:3])
print(s[1:-1])
print(s[2:])
print(s[:2])
print(s[:])

c = [21, 37]
d = c * 4
print(d)
print([0]*9)


s = [[-1, +1]] * 5
print(s)

s[2].append(7)
print(s)


w = "Tumiso is part of the jcrew team".split()
print(w)

i = w.index('jcrew')
print(i)

u = "jackdaws love my big sphinx of quartz".split()
print(u)
del u[3]
print(u)
u.remove('jackdaws')
print(u)

a = 'instead of chasing the just live your life'.split()
print(a)
a.insert(4, "paper")
print(a)

' '.join(a)

g = [1, 11, 21, 44, 59]
g.reverse()
print(g)

g.sort()
print(g)

g.sort(reverse=True)
print(g)

h = 'not perplexing do handwriting family where I illegibly know doctors'.split()
h.sort(key=len)
print(h)




