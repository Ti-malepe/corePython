range(5)

for i in range(5):
    print(i)

range (5, 10)

list(range( 5,15))

list(range(0, 10, 2))

s = [0, 1, 4, 6, 13]
for i in range(len(s)):
     print(s[i])


s = [0, 1, 4, 6, 13]
for v in s:
     print(v)

t = [6, 372, 8862, 14880, 25255]
for p in enumerate(t):
    print(p)
