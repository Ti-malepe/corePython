for x in {1, 2, 4, 8, 16, 32}:
  print(x)

  