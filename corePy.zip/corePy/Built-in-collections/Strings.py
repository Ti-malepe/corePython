
 len("Tumisomalepefromlimppopburgersfortgamotodi")

 "news" +" " + "from" + " " + "eNews"
'news from eNews'
colors = ';'.join(['#'])
>>> colours = ';'.join(['#45ff23','#2321fa', '#1298'])
>>> colors
'#'
>>> colours
'#45ff23;#2321fa;#1298'
>>> colors.split(';')
['#']
>>> colours.split(';')
['#45ff23', '#2321fa', '#1298']
>>> s = "news"
>>> s =+ "from"
Traceback (most recent call last):
  File "<pyshell#9>", line 1, in <module>
    s =+ "from"
TypeError: bad operand type for unary +: 'str'
>>> s += "from"
>>> s += "eNews"
>>> s
'newsfromeNews'
>>> "Tumisomalepepraesignis".partition(malepe)
Traceback (most recent call last):
  File "<pyshell#13>", line 1, in <module>
    "Tumisomalepepraesignis".partition(malepe)
NameError: name 'malepe' is not defined
 "Tumisomalepepraesignis".partition('malepe')
 

 "unforgetable".partition('forget')
('un', 'forget', 'able')
>>> "unfamiliar".partition('familiar')
('un', 'familiar', '')
departure, separator, arrival = "London:Edinburg".partition(':')
 departure
'London'
 arrival

>>> separator
':'
>>> "The age of {0} is {1}. {0}'s birthday is on {2}.format('fred', 24, 'October 31')
SyntaxError: EOL while scanning string literal
>>> "The age of {0} is {1}. {0}'s birthday is on {2}".format('fred', 24, 'October 31')
"The age of fred is 24. fred's birthday is on October 31"
>>> "Reticulating spine {} of {}".format(4,23)
'Reticulating spine 4 of 23'
>>> "current position {latitude} {longitude}".format(latitude="60N", longitude="5E")
'current position 60N 5E'
>>> value = 4 * 20
>>> f'The value is {value}'
'The value is 80'
>>> import datetime
>>> f'The current time is{datetime.datetime.now().isoformat()}.'
'The current time is2021-08-19T15:03:03.432294.'
>>> import math
>>> f'Math constants: pi={math.pi},e={math.e}'
'Math constants: pi=3.141592653589793,e=2.718281828459045'
>>> 