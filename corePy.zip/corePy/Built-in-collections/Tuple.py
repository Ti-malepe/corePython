Python 3.9.6 (tags/v3.9.6:db3ff76, Jun 28 2021, 15:26:21) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> t = ("Tumiso", 4.955. 8)
SyntaxError: invalid syntax
>>> t = ("Tumiso", 4.955, 8)
>>> t
('Tumiso', 4.955, 8)
>>> t[0]
'Tumiso'
>>> t[2]
8
>>> t[1]
4.955
>>> len(t)
3
>>> for item in t:
	print(item)

	
Tumiso
4.955
8
>>> t + (33816.0,265e9)
('Tumiso', 4.955, 8, 33816.0, 265000000000.0)
>>> def minmax(items):
	return(item), max(items)

>>> minmax([83, 33, 84, 32, 85, 31, 86])
(8, 86)
>>> lower, upper = minmax([83, 33, 84, 32, 85,])
>>> lower
8
>>> upper
85
>>> (a, (b, (c, d))) = (4,(3, (2, 1)))
>>> a
4
>>> b
3
>>> c
2
>>> d
1
>>> 