Python 3.9.6 (tags/v3.9.6:db3ff76, Jun 28 2021, 15:26:21) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> m = [9, 15, 24]
>>> def modify(k):
	k.append(39)
	print("k = ", k)

	
>>> modify(m)
k =  [9, 15, 24, 39]
>>> f = [14, 23, 37]
>>> def replace(g):
	g = [17, 28, 45]
	print("g =", g)

	
>>> replace(f)
g = [17, 28, 45]
>>> f
[14, 23, 37]
>>> def replace_contents(g):
	g[0] = 17
	g[1] = 28
	g[2] = 45
	print("g =",g)

	
>>> f
[14, 23, 37]
>>> replace_contents(f)
g = [17, 28, 45]
>>> f
[17, 28, 45]
>>> def f(d):
	return d

>>> c =[6, 10, 16]
>>> e = f(c)
>>> c
[6, 10, 16]
>>> c is e
True
>>> 