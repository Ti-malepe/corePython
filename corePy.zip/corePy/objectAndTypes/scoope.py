Python 3.9.6 (tags/v3.9.6:db3ff76, Jun 28 2021, 15:26:21) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> count =0
>>> def show_count():
	print(count)

	
>>> def set_count(c)
SyntaxError: invalid syntax
>>> def set_count(c):
	count = c

	
>>> show_count()
0
>>> def set_count(c):
	global count
	count = c

	
>>> show_count()
0
>>> show_count()
0
>>> set_count(5)
>>> show_count()
5
>>> 