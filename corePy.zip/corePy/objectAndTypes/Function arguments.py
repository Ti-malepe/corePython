import time

def banner(message, border='-'):
		line = border *len(message)
		print(line)
		print(message)
		print(line)


banner("Tumiso Malepe")

banner("sun,Moon and stars", "*")



banner(border= ".", message="hello earth people")


time.ctime()


def show_default(arg=time.ctime()):
		print(arg)
		show_default()

def add_spam(menu=[]):
		menu.append("spam")
		return menu

breakfast = ['bacon','eggs']
add_spam(breakfast)
['bacon', 'eggs', 'spam']
lunch = ['baked beans']
def add_spam(menu=None):
		if menu is None:
			menu = []
		menu.append('spam')
		return menu

add_spam()
['spam']
