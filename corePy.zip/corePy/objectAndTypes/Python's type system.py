Python 3.9.6 (tags/v3.9.6:db3ff76, Jun 28 2021, 15:26:21) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> def add(a + b):
	
SyntaxError: invalid syntax
>>> def add(a, b):
	return a + b

>>> add(5, 7)
12
>>> 
>>> add("new", "paper")
'newpaper'
>>> add([1, 6],[21, 107])
[1, 6, 21, 107]
>>> 