
def square(x):
 	return x * x

square(5)

def launch_missiles():
  	print("missiles launched!")

     

def even_or_odd(n)

  def even even_or_odd:
	

def even_or_odd(n):
	  if n % 2 == 0:
	  	print("even")
	 	return

	
 w = even_or_odd(31)

 nth_root(16, 2)
 nth_root(16,2)
def nth_root(radicand, n):
  	return radicand ** (1/n)


nth_root(27,3)

